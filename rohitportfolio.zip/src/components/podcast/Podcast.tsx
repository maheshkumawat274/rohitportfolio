import React from 'react';
import FeatureBtn from '../btns/FeatureBtn';

interface VideoCard {
  videoId: string;
  title: string;
  description: string;
  link: string;
}

const videoCards: VideoCard[] = [
  {
    videoId: 'WBI5atoH4Oo?si=r13EfZEoME7JdL11',
    title: 'How Can UX/UI Designers Earn More Than ₹2 Lakh Per Month?',
    description: 'Tips and strategies to increase your podcast listenership organically.',
    link: 'https://youtu.be/WBI5atoH4Oo?si=eO4v-ex4OatZtQnQ',
  },
  {
    videoId: 'FUzBiPQHriU?si=DRD1-b2uSXzEoLYS',
    title: '19 Year Old Boy Freelancer Earns ₹5 Lakh/Month with Video Editing?',
    description: 'A deep dive into advanced audio editing techniques for podcasts.',
    link: 'https://youtu.be/FUzBiPQHriU?si=LvV5vUlAVZ0xHiIU',
  },
  {
    videoId: 'nuMBN9TVDds?si=nwiQOhj12Vj5rqY5',
    title: '16 Year Old Girl Earns ₹1 Lakh/Month with Video Editing?',
    description: 'Learn proven monetization models and sponsorship strategies.',
    link: 'https://youtu.be/nuMBN9TVDds?si=OEUYbFnB59rT0Rht',
  },
  {
    videoId: 'PS-1HK_BVys?si=TV4HYCHLDHHT6uqw',
    title: 'UPSC Aspirants, Don’t Miss This Before You Start! ',
    description: 'Tips and strategies to increase your podcast listenership organically.',
    link: 'https://youtu.be/PS-1HK_BVys?si=kHHvtpaFhtm7xQ7f',
  },
  {
    videoId: '43LbnPWA9wY?si=WLxZrpN0PnvDvVFi',
    title: 'Before You Start an Agency in 2025 Watch This! (Real Talk) |',
    description: 'A deep dive into advanced audio editing techniques for podcasts.',
    link: 'https://youtu.be/43LbnPWA9wY?si=WLxZrpN0PnvDvVFi',
  },
  {
    videoId: 'nY00oIIFLQ4?si=CTvmiBr6r2HSTTYv',
    title: '₹1.2 CRORE Worth of Business Knowledge in 47 Minutes?',
    description: 'Learn proven monetization models and sponsorship strategies.',
    link: 'https://youtu.be/nY00oIIFLQ4?si=CTvmiBr6r2HSTTYv',
  },
];

const PodcastVideos: React.FC = () => (
  <section className="py-16 px-2 sm:px-6 bg-black">
    <div className="max-w-7xl mx-auto">
      <h1 className="text-4xl sm:text-6xl text-gray-300 font-bold text-center mb-3">Top podcasts:</h1>
      <p className=' text-xl sm:text-2xl text-gray-500 font-semibold text-center mb-12'>Discover the selection of the most popular podcasts.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {videoCards.map(({ videoId, title, description, link }) => (
          <div
            key={videoId}
            className="bg-[#0D0D0D] rounded-2xl shadow-lg overflow-hidden flex flex-col"
          >
            {/* Responsive YouTube iframe */}
            <div className="aspect-video w-full">
              <iframe
                className="w-full h-full"
                src={`https://www.youtube.com/embed/${videoId}`}
                title={title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>

            <div className="p-2 sm:p-6 flex flex-col flex-grow">
              <h2 className="text-xl font-semibold mb-2">{title}</h2>
              <p className="text-gray-400 flex-grow">{description}</p>
              <a
                href={link}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-block text-green-500 font-medium hover:underline"
              >
                Watch on YouTube →
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
    <div className='text-center pt-14'>
      <a 
      href='https://www.youtube.com/@therohitprashar'
      target="_blank"
      rel="noopener noreferrer"><FeatureBtn/></a>
    </div>
    
  </section>
);

export default PodcastVideos;
